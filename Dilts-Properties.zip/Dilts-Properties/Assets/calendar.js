<script>
      $(document).ready(function () {
        let calender = $("#calendar").fullCalendar();
      });
    </script>