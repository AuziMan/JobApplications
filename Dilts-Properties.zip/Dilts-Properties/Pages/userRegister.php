<?php
session_start ();

ini_set ( 'display_errors', '1' );
ini_set ( 'display_startup_errors', '1' );
error_reporting ( E_ALL );
?>

<!-- Michael Duisenberg -->
<!-- CST-236 -->
<!-- 01-12-21 -->
<!-- This page is the form for registering new users -->
<!-- Version 1.0 -->

<!DOCTYPE html>
<html>
<head>
<title>Registration</title>
<!-- style format centers form in the center of the screen, also adds a border -->

<?php include_once('../fragments/stylesheets.html'); ?>
<link href="../Assets/register.css" rel="stylesheet">

<meta charset="ISO-8859-1">
</head>

<!-- body section creates the form to get the users information -->
<body class="text-center">
	<!-- The required statements make sure that all data fields are entered when the user clicks submit, if they are not, a message pops up,
	 stating that a required field is missing -->


	<main class="form-register">
		<form action="./Page-Handlers/userRegisterHandler.php" method="post">
			<a class="navbar-brand" href="../Pages/index.php">Dilts Properties</a>
			<h1 class="h3 mb-3 fw-normal">Please Register</h1>
			<label for="inputFirstName" class="visually-hidden">First Name</label>
			<input type="text" id="inputFirstName" name="firstName"
				class="form-control" placeholder="First Name" required autofocus> <label
				for="inputLastName" class="visually-hidden">Last Name</label> <input
				type="text" id="inputLastName" name="lastName" class="form-control"
				placeholder="Last Name" required> <label for="inputEmail"
				class="visually-hidden">Email address</label> <input type="email"
				id="inputEmail" name="email" class="form-control"
				placeholder="Email address" required> <label for="inputPassword"
				class="visually-hidden">Password</label> <input type="password"
				id="inputPassword" name="passWord" class="form-control"
				placeholder="Password" required> <label for="inputPhoneNumber"
				class="visually-hidden">Phone Number</label> <input type="tel"
				id="inputPhoneNumber" name="phoneNumber" class="form-control"
				placeholder="(555) 555-5555" required>

			<button class="w-100 btn btn-lg btn-primary" type="submit">Register</button>
			<p class="mt-5 mb-3 text-muted">Already have an account?</p>
			<a href="userLogin.php">Sign in</a>
		</form>
	</main>

</body>
</html>