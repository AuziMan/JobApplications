<?php
/**
 * @author Michael Duisenberg & Zac Almas
 * @name CST-326 Group Project Landing page v1.0
 * @desc navbar - Landing page for user or admin
 */



// Start the session if its not started
if(!isset($_SESSION)) {
    session_start();
}

if(!isset($_SESSION['userRole'])){
	header("Location: ./userLogin.php");
}
?>

<html lang="en">
<head>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
  	<title>Dilts Lakeside Properties</title>
	
	<?php
 	// Error reporting support
 	ini_set('display_errors', '1');
 	ini_set('display_startup_errors', '1');
 	error_reporting(E_ALL);
  
    // Include the stylesheets page fragment
    include_once('../fragments/stylesheets.html');
    ?>
    
   
    <link rel="stylesheet" type="text/css" href="../Assets/pictureGrid.css">

	<script>
  // Get the elements with class="column"
  var elements = document.getElementsByClassName("column");

  // Declare a "loop" variable
  var i;

  // Full-width images
  function one() {
    for (i = 0; i < elements.length; i++) {
      elements[i].style.flex = "100%";
    }
  }

</script>

</head>
<body style="background-color:#F5F6FA" onload="one()">

	<?php include_once('../fragments/navbar.php')?>

	<p></p>
	<div id="carouselControls" class="carousel slide carousel-fade" data-bs-ride="carousel">		
		<div class="carousel-indicators">
    		<button type="button" data-bs-target="#carouselControls" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
    		<button type="button" data-bs-target="#carouselControls" data-bs-slide-to="1" aria-label="Slide 2"></button>
    		<button type="button" data-bs-target="#carouselControls" data-bs-slide-to="2" aria-label="Slide 3"></button>
    		<button type="button" data-bs-target="#carouselControls" data-bs-slide-to="3" aria-label="Slide 4"></button>
  		</div>		
  		<div class="carousel-inner" style="margin: 0 auto">
    		<div class="carousel-item active" data-mdb-interval="3000">
      			<img src="../Assets/outdoorPic1.png" width="480" height="320" class="d-block w-50" alt="House1" style="margin: auto">
    		</div>
    		<div class="carousel-item" data-mdb-interval="3000">
      			<img src="../Assets/outdoorPic2.png"  width="480" height="320" class="d-block w-50" alt="House2" style="margin: auto">
    		</div>
    		<div class="carousel-item" data-mdb-interval="3000">
     		 	<img src="../Assets/outdoorPic3.png"  width="480" height="320" class="d-block w-50" alt="House3" style="margin: auto">
    		</div>
    		<div class="carousel-item" data-mdb-interval="3000">
     		 	<img src="../Assets/outdoorPic4.png"  width="480" height="320" class="d-block w-50" alt="House3" style="margin: auto">
    		</div>
  		</div>
  		<button class="carousel-control-prev" type="button"data-bs-target="#carouselControls" data-bs-slide="prev" style="position: absolute; left: 200px;">
    		<span class="carousel-control-prev-icon" aria-hidden="true"></span>
    		<span class="visually-hidden">Previous</span>
  		</button>
  		<button class="carousel-control-next" type="button" data-bs-target="#carouselControls" data-bs-slide="next" style="position: absolute; right: 200px;">
    		<span class="carousel-control-next-icon" aria-hidden="true"></span>
    		<span class="visually-hidden">Next</span>
  		</button>
	</div>

	
	<p></p>
	
	<div class="grid">
	<div class="column">
    	<img src="../Assets/living.jpg" style="width:300px;height:400px;">
    	<img src="../Assets/dining1.jpg" style="width:300px;height:400px;">
    	<img src="../Assets/dining2.jpg" style="width:300px;height:400px;">
     </div>
	  <div class="column">
    	<img src="../Assets/lakePic1.jpg" style="width:300px;height:400px;">
    	<img src="../Assets/bedroomWindow.jpg" style="width:300px;height:400px;">
    	<img src="../Assets/FrontDeck.jpg" style="width:300px;height:400px;">
     </div>
     <div class="column">
    	<img src="../Assets/frontWindow.jpg" style="width:300px;height:400px;">
    	<img src="../Assets/frontWindow2.jpg" style="width:300px;height:400px;">
    	<img src="../Assets/byard.jpg" style="width:300px;height:400px;">
     </div>
      <div class="column">
    	<img src="../Assets/beach.jpg" style="width:300px;height:400px;">
    	<img src="../Assets/Tree1.jpg" style="width:300px;height:400px;">
    	<img src="../Assets/Plant1.jpg" style="width:300px;height:400px;">
     </div>
      <div class="column">
    	<img src="../Assets/Plant2.jpg" style="width:300px;height:400px;">
    	<img src="../Assets/backyard1.jpg" style="width:300px;height:400px;">
    	<img src="../Assets/FrontYardPlant.jpg" style="width:300px;height:400px;">
     </div>
	</div>
	

<?php include_once('../fragments/scripts.html');?>
  </body>
</html>
