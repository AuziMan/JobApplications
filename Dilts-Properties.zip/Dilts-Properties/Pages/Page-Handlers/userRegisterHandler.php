<?php
session_start ();
// require_once '../../../Autoloader.php';

?>

<!-- Michael Duisenberg -->
<!-- CST-236-->
<!-- 01-14-21-->
<!-- Topic 1 -->
<!-- This page handles the form gathering and inserts the data in the database-->
<!-- Version 1.0 -->

<!-- html was used around the PHP code in order to add CSS styling. -->
<html>
<head>
<title>Registration Complete</title>
<link rel="icon" href="../../../letter-b-64v-prints.png">
<link rel="stylesheet" href="../../../welcomeStyle.css">
<style>
/* centers output on screen */
p {
	height: 6em;
	position: relative;
	margin: 0;
	position: absolute;
	top: 50%;
	left: 50%;
	margin-right: -50%;
	transform: translate(-50%, -50%);
	text-align: center;
	background-color: #8BD5EF;
	width: 400px;
	border: 1px solid black;
}

body {
	background-color: grey;
}
</style>

</head>
<body>


	<p>
		
		
			<?php
			// require_once '../../Autoloader.php';
			require_once '../../Database/Database.php';

			
			$db = new Database();
			
			
			$connection = $db->getConnect();
			
			$Referral = "";
			//variables are set to the value of the data entered in the form if the connection to the database is made
			if($connection)
			{
			    $personFirst = ($_POST["firstName"]);
			    $personLast = ($_POST["lastName"]);
			    $email = $_POST["email"];
			    $passWord = $_POST["passWord"];
				  $phoneNumber = $_POST["phoneNumber"];
				  $Referral = $_POST["referral"];
			}

			// if the email chosen is already taken, prompt the user to enter a different one
			$sql_user = "SELECT * FROM users WHERE EMAIL = '$email'";
			$result_u = mysqli_query ( $connection, $sql_user );
			// $result_p = mysqli_query($conn, $sql_pass);

			$defaultRole = "User";

			// checks if the username and password combo already is in the database, if it is, outputs a warning
			// if not, inputs the data into the table and informs the user that they are now registered
			if (mysqli_num_rows ( $result_u ) > 0) {
				?>
					    <script>
					    	alert("Sorry... Please try a different email");
					    	window.location.replace('../userRegister.php');
					    </script>
					    <?php
					}
					else{
					    //$code = mt_rand(100000, 999999);
					    //mail($email,"Dilt's Properties Verification",'Hello. You just created an account with Dilts Properties. Use this code to verify your account: '.$code);
					    
					    ?>
<!-- 					    <script>
// 					    let answer = prompt("Enter the 6-digit code sent to your email.", "");
					    if (answer == null || answer == "" || answer!=<?php //echo $code?>) 
// 						    {
// 					    	alert("Wrong Code! Try Again.");
// 					    	window.location.replace('../userRegister.php');
					    	//exit?
// 					    }
					    </script> -->
					    <?php
					    $sql = "INSERT INTO `users` (`FIRSTNAME`, `LASTNAME`, `EMAIL`, `PASSWORD`, `PHONENUMBER`, `Role`, `Referral`) VALUES ( '$personFirst', '$personLast', '$email', '$passWord', '$phoneNumber', '$defaultRole', '$Referral')";
					    if (mysqli_query($connection, $sql)) 
					    {
					        if($Referral!="") {
					            $sql = "UPDATE `referrals` SET `used`=`used`+1 WHERE `code` = ".'"'.$Referral.'"';
    					        if (mysqli_query($connection, $sql))
    					        {
        							?>
        
        							<script>
        								alert("You are now registered!!")
        								window.location.replace('../userLogin.php');
        							</script>
        							<?php
    				            } 
					        }else { ?>
					        <script>
					        alert("Registered without Referal..")
					        window.location.replace('../userLogin.php');
					        </script> <?php  }
					    }else {
					echo "Error registering. Press the back button and try again<br>";
					echo "Error: " . $sql . "<br>" . mysqli_error ( $connection );
				}
				exit ();
			}
			?>
			</p>
	<p><?php include '../footer.php' ?> </p>
</body>
</html>