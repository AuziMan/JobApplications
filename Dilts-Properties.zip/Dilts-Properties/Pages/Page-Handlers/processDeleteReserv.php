<?php
session_start();
/*
 * Michael Duisenberg
 * Delete User handler
 * This page takes the id of the user, puts into a funtion that has the sql code for deleteing something from a
 * database and then deletes it
 * last updated 11-12-21
 */
include_once '../../Database/reservationsData.php';
?>

<title>Delete Confirmed</title>

<?php

if (isset ( $_GET )) {
	$id = $_GET ['id'];
} else
	echo "Nothing submited by the form";

// send a new user object to the buesness service -> database service chain

$ub = new reservationsData ();

if ($ub->deleteReserv ( $id )) {
	echo "Reservation Deleted.<br>";
} else {
	echo "Nothing Inserted.<br>";
}

if($_SESSION['userRole'] == "Admin"){
	echo "<a href='/Dilts-Properties/Pages/Admin/admin-reversations.php'>Return to Reservations Display</a>";
}
else {
	echo "<a href='/Dilts-Properties/Pages/past-reservations.php'>Return to Reservations Display</a>";
}
