<?php
session_start ();
// Michael Duisenberg
// 10-20-21
// CST-326
// Dilts Properties
// Login Handler
// connects the login.php page to the server and makes sure that the username and password are correct before letting someone in.
// Version 1.0

ini_set ( 'display_errors', '1' );
ini_set ( 'display_startup_errors', '1' );
error_reporting ( E_ALL );

include_once ('../../fragments/scripts.html');

require_once '../../Database/Database.php';
// require_once '../../fragments/Autoloader.php';

// create database object
$db = new Database ();

// get connection to database
$connection = $db->getConnect ();

// if connection was succsful
if ($connection) {
	$userEmail = $_POST ["email"];
	$loginPassWord = $_POST ["passWord"];
}

$sql = "SELECT * FROM `users` WHERE `EMAIL` = '$userEmail' AND `PASSWORD` = '$loginPassWord' LIMIT 1";
$result = mysqli_query ( $connection, $sql );
if (mysqli_num_rows ( $result ) == 0) {
	?>
<script type="text/javascript">
        console.log("User does not exist")
			  alert("Sorry... User does not exist");
			   window.location.replace('../userLogin.php');
      </script>
<?php
} 
else if (mysqli_num_rows ( $result ) == 1) {
	$row = mysqli_fetch_assoc ( $result );
	$_SESSION ['name'] = $row ['FIRSTNAME'];
	$_SESSION ['userid'] = $row ['ID'];
	$_SESSION ['userRole'] = $row ['Role'];

	// include 'main-welcome.php';
	// this line will cause the page to immeddlety jump to the next page
	header ( "Location: ../index.php" );
}

mysqli_close ( $connection );