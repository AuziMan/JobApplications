<?php
/*
 * Michael Duisenberg
 * Update user handler
 * This page processes the data taken from the edit user form and updates that user in the database
 * last updated 02-17-21
 * Milestone 3 of the Webstore application in PHP and web design level 2 class
 */
include_once '../../Buisness-service/User.php';
include_once '../../Database/UserDataService.php';

if (isset ( $_GET )) {
	$id = $_GET ['id'];
	$firstName = $_GET ['firstName'];
	$lastName = $_GET ['lastName'];
	$email = $_GET ['email'];
	$passWord = $_GET ['passWord'];
	$phoneNumber = $_GET ['phoneNumber'];
	$role = $_GET ['role'];
} else
	echo "Nothing submited by the form";

// create new User Database connection object
$ud = new UserDataService ();
$user = new User ( 0, $firstName, $lastName, $email, $passWord, $phoneNumber, $role );

// load the ID and user obejct into the function
if ($ud->editUser ( $id, $user )) {
	echo "User Updated.<br>";
} else {
	echo "Nothing Inserted.<br>";
}

echo "<a href='/Dilts-Properties/Pages/Admin/Adminpage-DisplayUsers.php'>Return to Product Display</a>";
    
    
    
