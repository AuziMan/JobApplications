<?php
require_once '../../Database/Database.php';

$db = new Database ();
$connection = $db->getConnect ();

$data = array ();

$query = "SELECT * FROM reservations ORDER BY ID";

$statement = $connection->prepare ( $query );

$statement->execute ();

$result = $statement->get_result ();

foreach ( $result as $row ) {
	$data [] = array (
			'id' => $row ["ID"],
			'title' => $row ["Title"],
			'start' => $row ["Check_In"],
			'end' => $row ["Check_Out"]
	);
}

echo json_encode ( $data );

// load.php

?>