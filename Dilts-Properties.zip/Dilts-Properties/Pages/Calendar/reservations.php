<?php
/**
 * Reservations page
 * This page implements FullCalendar.io to display a calendar to the screen, allowing users to select when they want to stay at the property
 * Designed by Austin and Michael
 */
include_once ('../../fragments/navbar.php');
include_once ('../../fragments/stylesheets.html');

ini_set ( 'display_errors', '1' );
ini_set ( 'display_startup_errors', '1' );
error_reporting ( E_ALL );
?>

<!DOCTYPE html>
<html lang="en">
<head>

<title>Reservations</title>
<meta charset="utf-8" />
<link rel="stylesheet"
	href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.4.0/fullcalendar.css" />

<script
	src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script
	src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
<script
	src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.18.1/moment.min.js"></script>
<script
	src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.4.0/fullcalendar.min.js"></script>

<style>
html, body {
	margin: 0;
	padding: 0;
	font-family: Arial, Helvetica Neue, Helvetica, sans-serif;
	font-size: 14px;
}

#calendar {
	max-width: 1200px;
	margin: 40px auto;
}
</style>
<script>
      $(document).ready(function () {
        var calendar = $("#calendar").fullCalendar({
          initialView: "dayGridMonth",
          validRange: function (nowDate) {
            //this prevents a user from being able to select a date that is in the past. The valid date range starts from today
            return {
              start: nowDate,
            };
          },
          selectable: true,
          header: {
            left: "prev,next today",
            center: "title",
            right: "addEventButton",
          },
          customButtons: {
            addEventButton: {
              text: "Make Reservation",
              click: function() {
                //alert("Hello There");
                $("#myModel").modal("toggle");
              }
            }
          },
         
          events: "loadCalender.php",
        });
      });
    </script>
</head>
<body>


	<!-- Modal -->
	<div class="modal fade" id="myModel" tabindex="-1"
		aria-labelledby="myModalLabel" aria-hidden="true">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title" id="myModalLabel">Date Selection</h5>
					<button type="button" class="btn-close" data-bs-dismiss="modal"
						aria-label="Close"></button>
				</div>
				<div class="modal-body">
					<form action="insert.php" method="post">
						<label for="inputEmail" class="visible">Start Date</label> <input
							type="date" id="startDate" name="startDate" class="form-control"
							required autofocus> <label for="inputPassword" class="visible">End
							Date</label> <input type="date" id="endDate" name="endDate"
							class="form-control" required>
						<button class="w-100 btn btn-lg btn-primary" type="submit">Submit</button>
				
				</div>
			</div>
		</div>
	</div>
	<div id="calendar"></div>
    <?php include_once('../../fragments/scripts.html');?>
  </body>
</html>
