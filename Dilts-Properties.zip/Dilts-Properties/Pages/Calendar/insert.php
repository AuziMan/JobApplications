
<?php
if (! isset ( $_SESSION )) {
	session_start ();
}
// insert.php
ini_set ( 'display_errors', '1' );
ini_set ( 'display_startup_errors', '1' );
error_reporting ( E_ALL );

require_once '../../Database/Database.php';
$db = new Database ();
$connection = $db->getConnect ();

$title = "Taken";
$start = $_POST ['startDate'];
$end = $_POST ['endDate'];
$userId = $_SESSION ['userid'];



$statement = $connection->prepare ( "INSERT INTO `reservations` (`Title`, `Check_In`, `Check_Out`, `users_ID`) VALUES ('$title', '$start', '$end', '$userId')" );
$statement->execute ();

if ($statement->affected_rows > 0) {
	?>
<script>
        alert("Reservation Confirmed!!")
        window.location.replace('/Dilts-Properties/Pages/Calendar/reservations.php');
    </script>
<?php
} else {
	return false;
}

?>