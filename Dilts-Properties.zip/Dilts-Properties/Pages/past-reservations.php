<?php
session_start();

/*
 * Michael Duisenberg
 * Admin display Users page
 * This page displays all the users in the database as well as allowing the Admin to add, edit or delete a user
 * last updated 02-17-21
 * Milestone 3 of the Webstore application in PHP and web design level 2 class
 */

?>



<!doctype html>
<html lang="en">
<head>
<!-- Required meta tags -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<!-- My own css file and icon -->




<?php 
  include_once('../fragments/stylesheets.html'); 
  include_once '../Database/reservationsData.php';
  include_once '../Buisness-service/reservation.php';

  ini_set('display_errors', '1');
 	ini_set('display_startup_errors', '1');
 	error_reporting(E_ALL);

   include_once '../fragments/navbar.php';
?>
<title>My Reservations</title>
</head>
<body>
	

 <?php
   $r = new reservationsData();

   //array to hold all users
   $reservations = array();
     //load users into array
   $reservations = $r->fetchByUserID($_SESSION['userid']);
 ?>

  

  <h2>My Reservations</h2>
      
    <div class="table-responsive">
      <table class="table table-striped table-sm">
        <thead>
          <tr>
            <th>Delete</th>
            <th>ID</th>
            <th>Title</th>
            <th>Check In</th>
            <th>Check Out</th> 
          </tr>
        </thead>
        <tbody>
          <?php 
            for($x = 0; $x < count($reservations); $x++)
            {
          ?>
          <tr>
            <td>
              <form action = "Admin/deleteReservation.php">
                <input type="hidden" name="id" value = "<?php echo $reservations[$x][0];?>"></input>
                <button type="submit">Delete</button>
              </form>
            </td>
            <td><?php echo $reservations[$x][0]?></td>
            <td><?php echo $reservations[$x][1]?></td>
            <td><?php echo $reservations[$x][2]?></td>
            <td><?php echo $reservations[$x][3]?></td>
          </tr>
          <?php  
            }
          ?> 
              
        </tbody>
      </table>
        </div>
      <?php include_once('../fragments/scripts.html');?>
</body>
</html>