<?php
session_start ();
/*
 * Michael Duisenberg
 * Edit user form
 * This page is the form for editing a user. It takes the data already in the database and
 * displays it in the form so the admin can update it
 * last updated 11-12-21
 */
?>

<title>Admin Page Edit User</title>
</head>
<body>
	<h1>Edit form</h1>
<body>
  
  <?php
		include_once ('../../fragments/stylesheets.html');
		include_once '../../Buisness-service/User.php';
		include_once '../../Database/UserDataService.php';
		include_once '../../../showNavBar.php';

		// index of the first array in the 2D users array
		$x = 0;
		$id = $_GET ['id'];
		$ud = new UserDataService ();
		$user = array ();
		$user = $ud->findByUserID ( $id )?>
  
  
<!-- Form displays the current values of the user, then allowing the admin to change said values -->
	<div class="container">
		<form action="../Page-Handlers/processEditUser.php">
			<div class="form-group">
				<input type="hidden" name="id" value="<?php echo $user[$x][0]?>">
			</div>
			<div class="form-group">
				<label for="formGroupExampleInput2">First Name</label> <input
					type="text" class="form-control" name="firstName"
					value="<?php echo $user[$x][1]?>" required />
			</div>
			<div class="form-group">
				<label for="formGroupExampleInput2">Last Name</label> <input
					type="text" class="form-control" name="lastName"
					value="<?php echo $user[$x][2]?>" required />
			</div>
			<div class="form-group">
				<label for="formGroupExampleInput2">Email</label> <input type="text"
					class="form-control" name="email" value="<?php echo $user[$x][3]?>"
					required />
			</div>
			<div class="form-group">
				<label for="formGroupExampleInput2">Password</label> <input
					type="text" class="form-control" name="passWord"
					value="<?php echo $user[$x][4]?>" required />
			</div>
			<div class="form-group">
				<label for="formGroupExampleInput2">Phone Number</label> <input
					type="text" class="form-control" name="phoneNumber"
					value="<?php echo $user[$x][5]?>" required />
			</div>
			<div class="form-group">
				<label for="formGroupExampleInput2">Role</label> <input type="text"
					class="form-control" name="role" value="<?php echo $user[$x][6]?>"
					required />
			</div>
			<div class="form-group">
				<input type="submit" value="Update" />
			</div>
		</form>
	</div>
	
<?php include_once('../../fragments/scripts.html');?>
  </body>
</html>
