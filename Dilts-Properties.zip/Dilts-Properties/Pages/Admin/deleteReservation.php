<?php
session_start ();
ini_set ( 'display_errors', '1' );
ini_set ( 'display_startup_errors', '1' );
error_reporting ( E_ALL );

include_once ('../../fragments/stylesheets.html');
include_once '../../Database/reservationsData.php';
include_once '../../Buisness-service/reservation.php';
include_once '../../Database/UserDataService.php';

?>
<style>
.postView {
	border: 1px solid black;
	padding: 20px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 10px;
	margin-top: 5px;
	width: 60%;
	border-radius: 10px;
	background-color: rgb(250, 250, 250);
	font-size: 1.2em;
	text-align: left;
}
</style>
<title>Admin Page Delete Reservation</title>
</head>
<body>
	<h1>Delete Page</h1>
<body>
  
  <?php
		include_once '../../fragments/navbar.php';
		$a = 0;
		$id = $_GET ['id'];
		$ud = new reservationsData ();
		$reservation = array ();

		$u = new UserDataService ();
		$user = array ();

		$reservation = $ud->fetchByID ( $id );

		?>
<h2>Please confirm your choice</h2>

	<div class="postView">
		<p>
  <?php

		for($x = 0; $x < count ( $reservation ); $x ++) {
			// gets the name of the user that made the reservation
			$userId = $reservation [$x] [4];
			$user = $u->findByUserID ( $userId );
			echo "Reservation ID - " . $reservation [$x] [0] . "<br>";
			echo "Reservation Title - " . $reservation [$x] [1] . "<br>";
			echo "Reservation Start Date - " . $reservation [$x] [2] . "<br>";
			echo "Reservation End Date - " . $reservation [$x] [3] . "<br>";
			echo "Reservation Booked By - " . $user [0] [1] . "<br>";
		}
		?>
</p>

		<p> <?php echo "Do you really want to delete this Reservation? <br>"?></p>
		<form action="../Page-Handlers/processDeleteReserv.php">
			<div class="form-group">
				<input type="hidden" name="id"
					value="<?php echo $reservation[$a][0]?>">
			</div>
			<div class="form-group">
				<input type="submit" value="Yes" />
			</div>
		</form>

		<a class="btn btn-outline-primary"
			href="../Admin/admin-reversations.php" role="button">No</a>
	</div>