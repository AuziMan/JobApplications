<?php
session_start();

/*
 * Michael Duisenberg
 * Admin display Users page
 * This page displays all the users in the database as well as allowing the Admin to add, edit or delete a user
 * last updated 02-17-21
 * Milestone 3 of the Webstore application in PHP and web design level 2 class
 */

if(!isset($_SESSION['userRole']) || $_SESSION['userRole'] != 'Admin'){
  header("Location: ../userLogin.php");
}

?>



<!doctype html>
<html lang="en">
<head>
<!-- Required meta tags -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<!-- My own css file and icon -->


<?php 
  include_once('../../fragments/stylesheets.html'); 
  include_once '../../Buisness-service/User.php';
  include_once '../../Database/UserDataService.php';
?>
<title>Admin Page</title>
</head>
<body>
	

 <?php
  include_once '../../fragments/navbar.php';
    //user database object
  $u = new UserDataService();
  //array to hold all users
  $users = array();
    //load users into array
  $users = $u->getAllUsers();
 ?>

  <a class="btn btn-outline-primary" href="AddUser.php" role="button">Add</a>     

        <h2>Users</h2>
      
        <div class="table-responsive">
          <table class="table table-striped table-sm">
            <thead>
              <tr>
                <th>Edit</th>
                <th>Delete</th>
                <th>ID</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Email</th>
                <th>Password</th>
                <th>Phone Number</th>
                <th>Role</th>
              </tr>
            </thead>
            <tbody>
            <?php 
            for($x = 0; $x < count($users); $x++)
            {
                ?>
                <tr>
              <td>
                  <form action = "EditUserForm.php">
                  <input type="hidden" name="id" value = "<?php echo $users[$x][0];?>"></input>
                    <button type="submit">Edit</button>
                </form>
        </td>
        <td>
                <form action = "DeleteUser.php">
                  <input type="hidden" name="id" value = "<?php echo $users[$x][0];?>"></input>
                    <button type="submit">Delete</button>
                </form>
        </td>
                <td><?php echo $users[$x][0]?></td>
                <td><?php echo $users[$x][1]?></td>
                <td><?php echo $users[$x][2]?></td>
                <td><?php echo $users[$x][3]?></td>
                <td><?php echo $users[$x][4]?></td>
                <td><?php echo $users[$x][5]?></td>
                <td><?php echo $users[$x][6]?></td>
              </tr>
              <?php  
            }
          ?> 
              
            </tbody>
          </table>
        </div>
      <?php include_once('../../fragments/scripts.html');?>
</body>
</html>
