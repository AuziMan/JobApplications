<?php
session_start();

/*
 * Michael Duisenberg
 * Admin display Users page
 * This page displays all the users in the database as well as allowing the Admin to add, edit or delete a user
 * last updated 02-17-21
 * Milestone 3 of the Webstore application in PHP and web design level 2 class
 */

ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);

?>


<!doctype html>
<html lang="en">
<head>
<!-- Required meta tags -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<!-- My own css file and icon -->
<link rel="icon" href="letter-b-64v-prints.png">
<script src="../../Assets/jquery-3.6.0.min.js"></script>

<?php 
  include_once('../../fragments/stylesheets.html');
  
  require_once '../../Database/Database.php';
  //require_once '../../fragments/Autoloader.php';
  
  //create database object
  $db = new Database();
  
  //get connection to database
  $connection = $db->getConnect();
  
  $codes = array();
  
  if($connection)
  {
      $sql = "SELECT * FROM `referrals` ORDER BY used ASC, ID DESC";
      $result = mysqli_query($connection,$sql); 
      $index = 0;
      while($row = $result->fetch_assoc())
      {
          $codes[$index] = array($row["ID"], $row["code"], $row["used"]);
          ++$index;
      }
  }
?>
<script type="text/javascript">
function NewCode()
{
	console.log("new referral button clicked");
	jQuery.ajax({
	    type: "POST",
	    url: '../../Database/ReferralAjaxService.php',
	    dataType: 'json',
	    data: {referral: 'create'},
	    success: function (data) 
	    {
	         alert(data.Message);         
	    }
	});
	location.reload();
}
</script>

<title>Generate SignUp</title>
</head>
<?php

  
  include_once '../../fragments/navbar.php';
  ?>
<body>
<div align="center"><button onclick="NewCode()">Create New Referral Code</button></div>
<div class="table-responsive">
          <table class="table table-striped table-sm">
            <thead>
              <tr>
                <th>ID</th>
                <th>Referral</th>
                <th>IsUsed</th>
              </tr>
            </thead>
            <tbody>
            <?php 
            for($x = 0; $x < count($codes); $x++)
            {
                ?>
                <tr>
                	<td><button value="delete" name="<?php echo $codes[$x][0]?>"type="submit">Delete <?php echo $codes[$x][0]?></button></td>
              		<td><?php echo $_SERVER['HTTP_HOST']."/Dilts-Properties/Pages/userRegister.php?referral=".$codes[$x][1]?></td>
              	 	<td><?php echo $codes[$x][2]?></td>
        	
              </tr>
              <?php  
            }
          ?> 
              
            </tbody>
          </table>
        </div>
        <?php include_once('../../fragments/scripts.html');?>
</body>
</html>