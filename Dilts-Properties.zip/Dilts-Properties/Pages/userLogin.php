<!-- Michael Duisenberg -->
<!-- CST-126 -->
<!-- 09-18-20 -->
<!-- This page is the form for loging in users -->
<!-- Version 2.0 -->
<?php
/**
 *
 * @author Michael Duisenberg
 * @name GCU Webstore 2.0
 *       login page - from here the user can login or select to register for an account
 */
?>

<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport"
	content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
<title>Sign In</title>
	
	<?php
	// Error reporting support
	ini_set ( 'display_errors', '1' );
	ini_set ( 'display_startup_errors', '1' );
	error_reporting ( E_ALL );

	// Start the session if its not started
	if (! isset ( $_SESSION )) {
		session_start ();
	}

	// Include the stylesheets page fragment
	include_once ('../fragments/stylesheets.html');
	?>
    <link href="../Assets/signin.css" rel="stylesheet">
<style>
.bd-placeholder-img {
	font-size: 1.125rem;
	text-anchor: middle;
	-webkit-user-select: none;
	-moz-user-select: none;
	user-select: none;
}

@media ( min-width : 768px) {
	.bd-placeholder-img-lg {
		font-size: 3.5rem;
	}
}
</style>

<!--Custom stylesheet for the sign in page. Designed by Bootstrap-->

</head>
<body class="text-center">

	<main class="form-signin">
		<form action="./Page-Handlers/userLoginHandler.php" method="post">
			<a class="navbar-brand" href="../Pages/index.php">Dilts Properties</a>
			<h1 class="h3 mb-3 fw-normal">Please sign in</h1>
			<label for="inputEmail" class="visually-hidden">Email address</label>
			<input type="email" id="inputEmail" name="email" class="form-control"
				placeholder="Email address" required autofocus> <label
				for="inputPassword" class="visually-hidden">Password</label> <input
				type="password" id="inputPassword" name="passWord"
				class="form-control" placeholder="Password" required>
			<div class="checkbox mb-3">
			</div>
			<button class="w-100 btn btn-lg btn-primary" type="submit">Sign in</button>
		</form>
	</main>
</body>
</html>