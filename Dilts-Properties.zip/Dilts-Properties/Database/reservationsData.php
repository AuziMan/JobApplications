<?php

require_once 'Database.php';
class reservationsData{

    function fetchAll(){
        
   
        $db = new Database();
        $connection = $db->getConnect();
        
        $data = array();
        
        $query = "SELECT * FROM reservations";
        
        $statement = $connection->prepare($query);
        
        $statement->execute();
        
        $result = $statement->get_result();
        $index = 0;
        foreach($result as $row)
        {
            $data[$index] = array(
            $row["ID"],
            $row["Title"],
            $row["Check_In"],
            $row["Check_Out"],
            $row["users_ID"]
            );
            ++$index;
        }
        
        return $data;
   
    }

    function fetchByUserID($userID){
        
   
        $db = new Database();
        $connection = $db->getConnect();
        
        //array to hold the reservations data
        $data = array();
        
        //prepare the sql statement
        $stmt = $connection->prepare("SELECT * FROM reservations WHERE users_ID LIKE ?");
        //string that is used in the statement
        $like_id = "%" . $userID . "%";
        //bind the string to the sql statment
        $stmt->bind_param("s", $like_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
    
        $index = 0;
        foreach($result as $row)
        {
            $data[$index] = array(
            $row["ID"],
            $row["Title"],
            $row["Check_In"],
            $row["Check_Out"],
            $row["users_ID"]
            );
            ++$index;
        }

       
        
        return $data;
    }


    function fetchByID($ID){
        
   
        $db = new Database();
        $connection = $db->getConnect();
        
        //array to hold the reservations data
        $data = array();
        
        //prepare the sql statement
        $stmt = $connection->prepare("SELECT * FROM reservations WHERE ID LIKE ?");
        //string that is used in the statement
        $like_id = "%" . $ID . "%";
        //bind the string to the sql statment
        $stmt->bind_param("s", $like_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
    
        $index = 0;
        foreach($result as $row)
        {
            $data[$index] = array(
            $row["ID"],
            $row["Title"],
            $row["Check_In"],
            $row["Check_Out"],
            $row["users_ID"]
            );
            ++$index;
        }

        return $data;
    }

    function deleteReserv($id) {
        $db = new Database();
        $connection = $db->getConnect();
        
        
        $stmt = $connection->prepare("DELETE FROM reservations WHERE ID = ?");
        
        if(!$stmt)
        {
            echo "Something went wrong in the binding process. sql error?";
            exit;
        }
        
        $stmt->bind_param("i", $id);
        
        $stmt->execute();
        
        if($stmt->affected_rows > 0)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
}