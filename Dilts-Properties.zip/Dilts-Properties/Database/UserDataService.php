<?php

require_once 'Database.php';

class UserDataService
{
    function getAllUsers()
    {
        $db = new Database();
        $connection = $db->getConnect();
        $stmt = $connection->prepare("SELECT * FROM users");
        $stmt->execute();
        
        $result = $stmt->get_result();
        
        if(!$result)
        {
            echo "Assume that sql statement has an error";
            exit;
        }
        
        if($result->num_rows == 0)
        {
            return null;
        }
       
        $index = 0;
        $users = array();
        
        while($row = $result->fetch_assoc())
        {
            $users[$index] = array($row["ID"], $row["FIRSTNAME"], $row["LASTNAME"], $row["EMAIL"], $row["PASSWORD"], $row["PHONENUMBER"], $row["Role"]);
            ++$index;
        }
        return $users;
    }
    
    
    function findByUserID($id){
        
        $db = new Database();
        $connection = $db->getConnect();
        
        
        $stmt = $connection->prepare("SELECT * FROM users WHERE ID LIKE ?");
        $like_id = "%" . $id . "%";
        $stmt->bind_param("s", $like_id);
        
        $stmt->execute();
        
        $result = $stmt->get_result();
        
        
        
        if(!$result)
        {
            echo "Assume that sql statement has an error";
            exit;
        }
        
        if($result->num_rows == 0)
        {
            return null;
        }
       
        
        $index = 0;
        $users = array();
        
        while($row = $result->fetch_assoc())
        {
            $users[$index] = array($row["ID"], $row["FIRSTNAME"], $row["LASTNAME"], $row["EMAIL"], $row["PASSWORD"], $row["PHONENUMBER"], $row["Role"]);
            ++$index;
        }
        return $users;
        
        
    }
    
    
    function makeNew($user)
    {
        $db = new Database();
        $connection = $db->getConnect();
        
        
        $stmt = $connection->prepare("INSERT INTO `users` (`FIRSTNAME`, `LASTNAME`, `EMAIL`, `PASSWORD`, `PHONENUMBER`, `Role`) VALUES (?,?,?,?,?,?)");
        
        $fn = $user->getFirstName();
        $ln = $user->getLastName();
        $e = $user->getEmail();
        $p = $user->getPassword();
        $pn = $user->getPhoneNumber();
        $r = $user->getRole();
        
        
      
        $stmt->bind_param("ssssss", $fn, $ln, $e, $p, $pn, $r);
        
        $stmt->execute();
        
        if($stmt->affected_rows > 0)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    
    function editUser($id, $user) {
        
        //make connection
        $db = new Database();
        $connection = $db->getConnect();
        $stmt = $connection->prepare("UPDATE users SET FIRSTNAME = ?, LASTNAME = ?, EMAIL = ?, PASSWORD = ?, PHONENUMBER = ?, Role = ? WHERE ID = ?");
        
        
        //information that will be updated
        $fn = $user->getFirstName();
        $ln = $user->getLastName();
        $e = $user->getEmail();
        $p = $user->getPassword();
        $pn = $user->getPhoneNumber();
        $r = $user->getRole();
        
        //bind the paramaters 
        $stmt->bind_param("ssssssi", $fn, $ln, $e, $p, $pn, $r, $id);
        
        $stmt->execute();
        
        if($stmt->affected_rows > 0)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    
    function deleteUser($id) {
        $db = new Database();
        $connection = $db->getConnect();
        
        
        $stmt = $connection->prepare("DELETE FROM users WHERE ID = ?");
        
        if(!$stmt)
        {
            echo "Something went wrong in the binding process. sql error?";
            exit;
        }
        
        $stmt->bind_param("i", $id);
        
        $stmt->execute();
        
        if($stmt->affected_rows > 0)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    
    
}