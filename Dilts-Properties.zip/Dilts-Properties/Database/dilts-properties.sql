-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Dec 15, 2021 at 05:35 AM
-- Server version: 5.7.24
-- PHP Version: 7.4.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dilts-properties`
--

-- --------------------------------------------------------

--
-- Table structure for table `check-out-pictures`
--

CREATE TABLE `check-out-pictures` (
  `ID` int(11) NOT NULL,
  `picture` varbinary(5) DEFAULT NULL,
  `reservations_ID` int(11) NOT NULL,
  `reservations_users_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `referrals`
--

CREATE TABLE `referrals` (
  `ID` int(11) NOT NULL,
  `code` varchar(256) NOT NULL,
  `used` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `referrals`
--

INSERT INTO `referrals` (`ID`, `code`, `used`) VALUES
(36, 'NEWONE', 0),
(41, 'e457a16f0c14f0210b5a279ea3428fdc7943d83fa24f19f69255c85e83f29fb3', 1),
(42, 'fc81ac156d1734768cb1a8e616d0e6001a29f889a47114231a42c3e0cd4d0a5f', 0),
(43, '385eec197775cdc18b8aa60a2010446886679277de48c877c88cec00dbcd8602', 0),
(44, 'c2416ab5ea8dcd0e963703602ff95fecd8e2b9d2f58da9547d7f6efb88090b4a', 1),
(45, 'd264c1e690f8bb33594690551f0d10fdc7fb0cbcfdc1b96ed9ab368a55d6cc3a', 1),
(46, '6087451e18562549e24d5329bbafc8c42f9eec38d3829e6afa86dbb2fbab3ea0', 0),
(47, 'fbb2eb4d2f7dd2afc2023dde0f7c61ddba6bc15329af3c1ad00354c1d402245e', 0),
(48, '8ce313f8f6e42c3fd61f990cacc124dc41c5d00731abf5f231fe6c7e7a33d255', 0),
(49, 'd7884d7b26ff1a1b2385405ad3ecbc4483ce22dad103f3fce4e8a89c756ab203', 0),
(50, 'b149b55faa6cbf3cadc0711055ea1aaf4bc6f3726fe165676a139fa5570f14c5', 0);

-- --------------------------------------------------------

--
-- Table structure for table `reservations`
--

CREATE TABLE `reservations` (
  `ID` int(11) NOT NULL,
  `Title` varchar(45) NOT NULL,
  `Check_In` date DEFAULT NULL,
  `Check_Out` date DEFAULT NULL,
  `users_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `reservations`
--

INSERT INTO `reservations` (`ID`, `Title`, `Check_In`, `Check_Out`, `users_ID`) VALUES
(5, 'Taken', '2021-12-27', '2021-12-30', 3),
(6, 'Taken', '2022-01-03', '2022-01-13', 3),
(7, 'Taken', '2022-01-26', '2022-01-31', 3),
(8, 'Taken', '2021-12-12', '2021-12-13', 3),
(10, 'Taken', '2021-12-24', '2021-12-24', 3);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `ID` int(11) NOT NULL,
  `FIRSTNAME` varchar(12) NOT NULL,
  `LASTNAME` varchar(50) NOT NULL,
  `EMAIL` varchar(50) NOT NULL,
  `PASSWORD` varchar(50) NOT NULL,
  `PHONENUMBER` varchar(11) NOT NULL,
  `Role` varchar(11) NOT NULL,
  `Referral` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`ID`, `FIRSTNAME`, `LASTNAME`, `EMAIL`, `PASSWORD`, `PHONENUMBER`, `Role`, `Referral`) VALUES
(1, 'Sam', 'Smith', 'example@example.com', 'example', '8324859632', 'Admin', ''),
(3, 'Zac', 'Almas', 'zacattack@zac.com', 'zacrocks', '5555555555', 'User', ''),
(4, 'Michael', 'Duisenberg', 'mrduise@gmail.com', 'some', '7078887248', 'User', ''),
(5, 'Glenda ', 'Dilts', 'glenda.dilts@gmail.com', 'professor', '9999999999', 'Admin', ''),
(6, 'Katherine', 'Duisenberg', 'kduise@gmail.com', 'some', '7078887248', 'User', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `check-out-pictures`
--
ALTER TABLE `check-out-pictures`
  ADD PRIMARY KEY (`ID`,`reservations_ID`,`reservations_users_ID`),
  ADD KEY `fk_check-out-pictures_reservations1_idx` (`reservations_ID`,`reservations_users_ID`);

--
-- Indexes for table `referrals`
--
ALTER TABLE `referrals`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `reservations`
--
ALTER TABLE `reservations`
  ADD PRIMARY KEY (`ID`,`users_ID`),
  ADD KEY `fk_reservations_users1_idx` (`users_ID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `check-out-pictures`
--
ALTER TABLE `check-out-pictures`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `referrals`
--
ALTER TABLE `referrals`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `reservations`
--
ALTER TABLE `reservations`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `check-out-pictures`
--
ALTER TABLE `check-out-pictures`
  ADD CONSTRAINT `fk_check-out-pictures_reservations1` FOREIGN KEY (`reservations_ID`) REFERENCES `reservations` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `reservations`
--
ALTER TABLE `reservations`
  ADD CONSTRAINT `fk_reservations_users1` FOREIGN KEY (`users_ID`) REFERENCES `users` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
