<?php 
require_once 'Database.php';

//create database object
$db = new Database();

//get connection to database
$connection = $db->getConnect();

switch($_POST["referral"])
{ //ajax request
        case 'create': 
            {
                $str = rand();
                $result = hash("sha256", $str);
                if($connection)
                {
                    $sqlDupe = "SELECT * FROM `referrals` WHERE `code` = `$result`";
                    $DupeResult = mysqli_query($connection, $sqlDupe);
                    if (mysqli_num_rows($DupeResult) == 0)
                    {
                        $sql = "INSERT INTO `referrals` (`code`, `used`) VALUES ('$result', 0)";
                        if (mysqli_query($connection, $sql))
                        {
                            echo json_encode(array("Message"=>"Success"));
                        }
                        else 
                        {
                            echo json_encode(array("Message"=>"error creating referral..."));
                        }
                    }
                    else //duplicate case
                    {
                        $result = hash("sha256", $str);
                        $sql = "INSERT INTO `referrals` (`code`, `used`) VALUES ('$result', 0)";
                        if (mysqli_query($connection, $sql))
                        {
                            echo json_encode(array("Message"=>"Success"));
                        }
                        else
                        {
                            echo json_encode(array("Message"=>"error creating referral..."));
                        }
                    }
                }
            }
            break;      
}
    ?>