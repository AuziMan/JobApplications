<?php

    class reservation {
        private $id;
        private $title;
        private $userId; // Property used to hold the user's id
        private $startDate; // Property used to hold the start date of the reservation
        private $endDate; // Property used to hold the end date of the reservation
    
        function __construct($id, $title, $user_ID, $start_Date, $end_Date)
        {
            $this->id = $id;
            $this->title = $title;
            $this->userId = $user_ID;
            $this->startDate = $start_Date;
            $this->endDate = $end_Date;
        }
        

        //setters
        function setId($newId){
            $this->id = $newId;
        }

        function setTitle($newTitle){
            $this->title = $newTitle;
        }

        function setStartDate($newStartDate){
            $this->startDate = $newStartDate;
        }
        
        function setEndDate($newEndDate){
            $this->endDate = $newEndDate;
        }
        //Getters and Setters
        function getId(){
            return $this->id;
        }
        
        function getStartDate(){
            return $this->startDate;
        }
        
        function getEndDate(){
            return $this->endDate;
        }
        
        function getUserId(){
            return $this->userId;
        }

        function getTitle(){
            return $this->title;
        }

        
    }
    

?>