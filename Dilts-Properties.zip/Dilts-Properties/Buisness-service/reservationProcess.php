<?php

    class reservation {
        public $userId; // Property used to hold the user's id
        public $startDate; // Property used to hold the start date of the reservation
        public $endDate; // Property used to hold the end date of the reservation
    
        function __construct($user_ID, $start_Date, $end_Date)
        {
            $this->userId = $user_ID;
            $this->startDate = $start_Date;
            $this->endDate = $end_Date;
        }
        
        //Getters and Setters
        function setStartDate($newStartDate)
        {
            $this->startDate = $newStartDate;
        }
        
        function setEndDate($newEndDate)
        {
            $this->endDate = $newEndDate;
        }
        
        function getStartDate()
        {
            return $this->startDate;
        }
        
        function getEndDate()
        {
            return $this->endDate;
        }
        
        function getId()
        {
            return $this->userId;
        }
        
    }
    

?>