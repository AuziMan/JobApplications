<?php


class User
{
    private $id;
    private $firstName;
    private $lastName;
    private $email;
    private $phoneNumber;
    private $passWord;
    private $role;
    
    
    public function __construct($id, $firstName, $lastName,$email,$passWord, $phoneNumber, $role)
    {
        $this->id = $id;
        $this->firstName = $firstName;
        $this->lastName = $lastName;
        $this->email = $email;
        $this->phoneNumber = $phoneNumber;
        $this->passWord = $passWord;
        $this->role = $role;
    }
    
    //getters
    public function getID() {
        return $this->id;
    }
    public function getFirstName() {
        return $this->firstName;
    }
    public function getLastName() {
        return $this->lastName;
    }
    public function getEmail() {
        return $this->email;
    }
    public function getPhoneNumber(){
        return $this->phoneNumber;
    }
    public function getPassword() {
        return $this->passWord;
    }
    public function getRole() {
        return $this->role;
    }
    
    //setter
    public function setID($id) {
        $this->id = $id;
    }
    public function setFirstName($firstName) {
         $this->firstName = $firstName;
    }
    public function setLastName($lastName) {
        $this->lastName = $lastName;
    }
    public function setEmail($email) {
         $this->email = $email;
    }
    public function setPassword($passWord) {
        $this->passWord = $passWord;
    }
    public function setPhoneNumber($phoneNumber){
        $this->phoneNumber = $phoneNumber;
    }
    public function setRole($role) {
        $this->role = $role;
    }
    
}

