# Dilt's Properties
>This project is still a work in progress

**Developers**
<br/>
* Michael Duisenberg
* Zac Almas
* Austin Driver
* Brian Basinger
* Toan Nguyen

## Program Description
This is an airbnb style website for a single client's property. 
<br/>
It is a private website that only the owner can allow access to.

### Operation Description
A user with an authorized account can select a date from the website's calendar and reserve the owner's lake house for that day.

### Technical Capabilities
1. Register and Log in.
2. Date reservations.
3. Automatic email's for reservations and registration.
4. Ability to view personal reservation history.
5. Account customization.
6. Admin controls
   - Account creation and removal.
   - View customer logs and reservation history.
   - View the pictures that customers upload after their stay.
   - Remove reservations.
   - Remove date's from calendar so user's cannot reserve.
