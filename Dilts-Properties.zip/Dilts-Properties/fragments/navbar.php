<?php

/**
 * @author Michael Duisenberg
 * @name Dilts-properties
 * @desc navbar - This is a page fragment for the navbar. The layout is based off Amazon's navbar
 */

if(!isset($_SESSION)){
    session_start();
}



//require_once 'Autoloader.php';


// If the customer is logged in 
if($_SESSION['userRole'] == "User") {

?>

<nav class="navbar navbar-expand-lg navbar-dark rounded" style="background-color:#4F6073; margin: 15px">
  <div class="container-fluid">
    <a class="navbar-brand" href="/Dilts-Properties/Pages/index.php">Dilts Properties</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
		  My Account
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item" href="/Dilts-Properties/Pages/past-reservations.php">Past Reservations</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="/Dilts-Properties/fragments/logOut.php">Logout</a></li>
          </ul>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="/Dilts-Properties/Pages/Calendar/reservations.php">Make Reservation</a>
        </li>
      </ul>
    </div>
  </div>
</nav>
<?php
}

//If user is an admin, only able to modify users, products, and see all past orders
else if($_SESSION['userRole'] == "Admin"){
    ?>
  <nav class="navbar navbar-expand-lg navbar-dark rounded" style="background-color:#4F6073; margin: 15px">
    <div class="container-fluid">
      <a class="navbar-brand" href="/Dilts-Properties/Pages/index.php">Dilts Properties</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            M A N A G E
            </a>
            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
              <li><a class="dropdown-item" href="/Dilts-Properties/Pages/Admin/Adminpage-DisplayUsers.php">Users</a></li>
              <li><a class="dropdown-item" href="/Dilts-Properties/Pages/Admin/admin-reversations.php">Reservations</a></li>
              <li><a class="dropdown-item" href="#">Reports</a></li>
              <li><hr class="dropdown-divider"></li>
              <li><a class="dropdown-item" href="/Dilts-Properties/fragments/logOut.php">Logout</a></li>
            </ul>
          </li>
        </ul>
      </div>
    </div>
  </nav>
<?php
    
}



